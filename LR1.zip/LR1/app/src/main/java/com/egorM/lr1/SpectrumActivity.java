package com.egorM.lr1;

import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.math3.complex.Complex;
import org.apache.commons.math3.transform.*;

public class SpectrumActivity extends AppCompatActivity {

    public GraphView spectrumView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {   // savedInstanceState - состояние приложения
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spectrum);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        spectrumView = findViewById(R.id.spectrum);

        double amplitude = getIntent().getDoubleExtra("amplitude", 2.0);
        double frequency = getIntent().getDoubleExtra("frequency", 2.0);
        double phase = getIntent().getDoubleExtra("phase", 2.0);
        double time = getIntent().getDoubleExtra("time", 2.0);

        // берём 1024 потому что для FFT требуется массив со степенью двойки
        int pointsCount = 1024;
        double[] signal = new double[pointsCount];

        for (int i = 0; i < pointsCount; i++) {
            double t = i * time / pointsCount; // разбиваем интервал от 0 до time на pointsCount равных шагов
            signal[i] = amplitude * Math.sin(2 * Math.PI * frequency * t + phase);
        }

        double[] spectrum = SpectrumActivity.calculateAmpSpectrum(signal);

        double fs = pointsCount / time; // частота дискретизации

        List<DataPoint> spectrumPoints = new ArrayList<>();
        for (int i = 0; i < spectrum.length; i++) {
            double freq = i * fs / signal.length; // ось частот
            double amp = spectrum[i];             // ось амплитуд
            spectrumPoints.add(new DataPoint(freq, amp));
        }

        LineGraphSeries<DataPoint> seriesSpectrum = new LineGraphSeries<>(spectrumPoints.toArray(new DataPoint[0]));

        seriesSpectrum.setColor(Color.RED);
        seriesSpectrum.setDrawDataPoints(false);
        seriesSpectrum.setThickness(3);

        spectrumView.addSeries(seriesSpectrum);
    }

    public static double[] calculateAmpSpectrum (double[] signal) {
        FastFourierTransformer fft = new FastFourierTransformer(DftNormalization.STANDARD); // создаем объект БПФ
        Complex[] result = fft.transform(signal, TransformType.FORWARD);                    // прямое преобразование фурье

        double[] amplitude = new double[result.length / 2];
        for (int i = 0; i < amplitude.length; i++) {
            amplitude[i] = result[i].abs() / signal.length; // нормализация
        }
        return amplitude;
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}