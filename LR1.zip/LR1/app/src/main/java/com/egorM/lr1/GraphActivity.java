package com.egorM.lr1;

import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.List;

public class GraphActivity extends AppCompatActivity {

    public GraphView graphView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        graphView = findViewById(R.id.graph);

        double amplitude = getIntent().getDoubleExtra("amplitude", 2.0);
        double frequency = getIntent().getDoubleExtra("frequency", 2.0);
        double phase = getIntent().getDoubleExtra("phase", 2.0);
        double point = getIntent().getDoubleExtra("points", 2.0);
        double time = getIntent().getDoubleExtra("time", 2.0);

        List<DataPoint> dataPoints = new ArrayList<>();

        // количество точек
        for (int i = 0; i <= point; i++) {
            double t = i * time / point;
            double y = amplitude * Math.sin(2 * Math.PI * frequency * t + phase);
            dataPoints.add(new DataPoint(t, y));
        }

        // Создание линии для графика
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(dataPoints.toArray(new DataPoint[0]));
        series.setColor(Color.BLUE);
        series.setDrawDataPoints(false);
        series.setThickness(3);

        // Добавление линии на график
        graphView.addSeries(series);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
