package com.egorM.lr1;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    public EditText amplitude_input;
    public EditText frequency_input;
    public EditText phase_input;
    public EditText points_input;
    public EditText time_input;
    public Button show_graph;
    public Button show_spectrum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {   // savedInstanceState - состояние приложения
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        // связываем переменные с элементами из activity_main.xml
        amplitude_input = findViewById(R.id.amplitude_input);
        frequency_input = findViewById(R.id.frequency_input);
        phase_input = findViewById(R.id.phase_input);
        points_input = findViewById(R.id.points_input);
        time_input = findViewById(R.id.time_input);
        show_graph = findViewById(R.id.show_graph);
        show_spectrum = findViewById(R.id.show_spectrum);

        // по нажатию кнопки, записываем в переменные значения, введенные пользователем
        show_graph.setOnClickListener(view -> {
            if (validateInputs()) {
                double amplitude = Double.parseDouble(amplitude_input.getText().toString());
                double frequency = Double.parseDouble(frequency_input.getText().toString());
                double phase = Double.parseDouble(phase_input.getText().toString());
                double points = Double.parseDouble(points_input.getText().toString());
                double time = Double.parseDouble(time_input.getText().toString());

                // передаем на следующий экран
                Intent intent = new Intent(MainActivity.this, GraphActivity.class);
                intent.putExtra("amplitude", amplitude);
                intent.putExtra("frequency", frequency);
                intent.putExtra("phase", phase);
                intent.putExtra("points", points);
                intent.putExtra("time", time);

                startActivity(intent);
            }
        });

        show_spectrum.setOnClickListener(view -> {
            if (validateInputs()) {
                double amplitude = Double.parseDouble(amplitude_input.getText().toString());
                double frequency = Double.parseDouble(frequency_input.getText().toString());
                double phase = Double.parseDouble(phase_input.getText().toString());
                double points = Double.parseDouble(points_input.getText().toString());
                double time = Double.parseDouble(time_input.getText().toString());

                // передаем на следующий экран
                Intent intent = new Intent(MainActivity.this, SpectrumActivity.class);
                intent.putExtra("amplitude", amplitude);
                intent.putExtra("frequency", frequency);
                intent.putExtra("phase", phase);
                intent.putExtra("points", points);
                intent.putExtra("time", time);

                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private boolean validateInputs() {
        String amplitudeStr = amplitude_input.getText().toString();
        String frequencyStr = frequency_input.getText().toString();
        String phaseStr = phase_input.getText().toString();
        String pointsStr = points_input.getText().toString();
        String timeStr = time_input.getText().toString();

        if (amplitudeStr.isEmpty() || frequencyStr.isEmpty() || phaseStr.isEmpty() ||
                pointsStr.isEmpty() || timeStr.isEmpty()) {
            Toast.makeText(this, "Пожалуйста, заполните все поля", Toast.LENGTH_SHORT).show();
            return false;
        }

        try {
            Double.parseDouble(amplitudeStr);
            Double.parseDouble(frequencyStr);
            Double.parseDouble(phaseStr);
            Double.parseDouble(pointsStr);
            Double.parseDouble(timeStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Некорректный формат числа", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true; // Все проверки пройдены
    }
}