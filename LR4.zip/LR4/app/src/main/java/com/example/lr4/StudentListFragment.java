package com.example.lr4;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.fragment.app.Fragment;

/**
 * Фрагмент для отображения списка студентов.
 * Использует ArrayAdapter с данными из ресурсов и одиночный выбор элемента.
 * Уведомляет родительскую активность о выборе студента через интерфейс OnStudentSelectedListener.
 */
public class StudentListFragment extends Fragment {

    /** Интерфейс для уведомления о выборе студента родительской активностью. */
    public interface OnStudentSelectedListener {
        /**
         * Вызывается при выборе студента в списке.
         *
         * @param studentId позиция выбранного студента в списке
         */
        void onStudentSelected(int studentId);
    }

    /** Слушатель выбора студента для передачи событий в MainActivity. */
    private OnStudentSelectedListener listener;

    /** ListView для отображения списка студентов. */
    private ListView listView;

    /**
     * Создает и настраивает view фрагмента со списком студентов.
     * Инициализирует ArrayAdapter, устанавливает режим выбора и обработчик кликов.
     *
     * @param inflater инфлятор для создания view
     * @param container родительский контейнер
     * @param savedInstanceState сохраненное состояние фрагмента
     * @return созданный view фрагмента
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_student_list, container, false);
        listView = view.findViewById(R.id.student_list);

        String[] students = getResources().getStringArray(R.array.student_names);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_list_item_activated_1, students);
        listView.setAdapter(adapter);

        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (listener != null) {
                    listener.onStudentSelected(position);
                }
                listView.setItemChecked(position, true);
            }
        });

        return view;
    }

    /**
     * Прикрепляет фрагмент к контексту и инициализирует слушатель.
     * Проверяет, что контекст реализует OnStudentSelectedListener (MainActivity).
     *
     * @param context контекст активности
     */
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnStudentSelectedListener) {
            listener = (OnStudentSelectedListener) context;
        }
    }

    /**
     * Открепляет фрагмент и очищает ссылку на слушатель.
     * Предотвращает утечки памяти при уничтожении фрагмента.
     */
    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}