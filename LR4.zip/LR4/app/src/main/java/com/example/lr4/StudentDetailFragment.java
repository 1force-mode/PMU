package com.example.lr4;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

/**
 * Фрагмент для отображения детальной информации о выбранном студенте.
 * Загружает данные из ресурсов массивов (имя, группа, оценка) по индексу студента.
 * Поддерживает создание экземпляра с аргументами и обновление данных динамически.
 */
public class StudentDetailFragment extends Fragment {

    /** Ключ аргумента для передачи ID студента при создании фрагмента. */
    private static final String ARG_STUDENT_ID = "student_id";

    /** ID текущего отображаемого студента. */
    private int currentStudentId = 0;

    /** TextView для отображения имени студента. */
    private TextView tvNameValue;

    /** TextView для отображения группы студента. */
    private TextView tvGroupValue;

    /** TextView для отображения оценки студента. */
    private TextView tvMarkValue;

    /**
     * Создает новый экземпляр фрагмента с указанным ID студента.
     * Используется для передачи аргументов при создании фрагмента.
     *
     * @param studentId ID студента для отображения
     * @return новый экземпляр StudentDetailFragment
     */
    public static StudentDetailFragment newInstance(int studentId) {
        StudentDetailFragment fragment = new StudentDetailFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_STUDENT_ID, studentId);
        fragment.setArguments(args);
        return fragment;
    }

    /**
     * Создает и настраивает view фрагмента.
     * Инициализирует TextView компоненты и восстанавливает ID студента из состояния или аргументов.
     *
     * @param inflater инфлятор для создания view
     * @param container родительский контейнер
     * @param savedInstanceState сохраненное состояние фрагмента
     * @return созданный view фрагмента
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_student_detail, container, false);

        tvNameValue = view.findViewById(R.id.tv_name_value);
        tvGroupValue = view.findViewById(R.id.tv_group_value);
        tvMarkValue = view.findViewById(R.id.tv_mark_value);

        if (savedInstanceState != null) {
            currentStudentId = savedInstanceState.getInt(ARG_STUDENT_ID, 0);
        } else if (getArguments() != null) {
            currentStudentId = getArguments().getInt(ARG_STUDENT_ID, 0);
        }

        updateStudentDetail();
        return view;
    }

    /**
     * Обновляет отображаемые данные фрагмента для нового студента.
     * Вызывается из MainActivity при выборе студента в двухпанельном режиме.
     *
     * @param studentId ID студента для отображения
     */
    public void updateStudent(int studentId) {
        currentStudentId = studentId;
        updateStudentDetail();
    }

    /**
     * Обновляет содержимое TextView на основе текущего ID студента.
     * Загружает данные из ресурсов массивов и проверяет границы индекса.
     * При некорректном ID очищает все поля.
     */
    private void updateStudentDetail() {
        String[] names = getResources().getStringArray(R.array.student_names);
        String[] groups = getResources().getStringArray(R.array.student_groups);
        String[] marks = getResources().getStringArray(R.array.student_marks);

        if (currentStudentId >= 0 &&
                currentStudentId < names.length &&
                currentStudentId < groups.length &&
                currentStudentId < marks.length) {

            tvNameValue.setText(names[currentStudentId]);
            tvGroupValue.setText(groups[currentStudentId]);
            tvMarkValue.setText(marks[currentStudentId]);
        } else {
            tvNameValue.setText("");
            tvGroupValue.setText("");
            tvMarkValue.setText("");
        }
    }

    /**
     * Сохраняет ID текущего студента в состоянии фрагмента.
     * Вызывается системой перед уничтожением фрагмента для восстановления состояния.
     *
     * @param outState Bundle для сохранения состояния
     */
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(ARG_STUDENT_ID, currentStudentId);
    }
}