package com.example.lr4;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

/**
 * Главная активность приложения для отображения списка студентов и деталей выбранного студента.
 * Поддерживает двухпанельный макет для планшетов и однопанельный для телефонов с использованием фрагментов.
 * Реализует интерфейс {@link StudentListFragment.OnStudentSelectedListener} для обработки выбора студента.
 */
public class MainActivity extends AppCompatActivity
        implements StudentListFragment.OnStudentSelectedListener {

    /** Тег для фрагмента списка студентов в FragmentManager. */
    private static final String LIST_FRAGMENT_TAG = "list";

    /** Тег для фрагмента деталей студента в FragmentManager. */
    private static final String DETAIL_FRAGMENT_TAG = "detail";

    /** Ключ для сохранения ID выбранного студента в Bundle состояния. */
    private static final String STATE_STUDENT_ID = "state_student_id";

    /** ID текущего выбранного студента. Инициализируется нулем. */
    private int currentStudentId = 0;

    /**
     * Инициализирует активность, устанавливает layout и восстанавливает состояние.
     * Вызывается при создании активности. Настраивает фрагменты в зависимости от ориентации.
     *
     * @param savedInstanceState сохраненное состояние активности, может содержать ID студента
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            currentStudentId = savedInstanceState.getInt(STATE_STUDENT_ID, 0);
        }

        setupFragments(savedInstanceState);
    }

    /**
     * Настраивает фрагменты в зависимости от макета и сохраненного состояния.
     * Всегда создает фрагмент списка студентов. В двухпанельном режиме создает/обновляет фрагмент деталей.
     *
     * @param savedInstanceState сохраненное состояние для восстановления фрагментов
     */
    private void setupFragments(Bundle savedInstanceState) {
        FragmentManager fm = getSupportFragmentManager();

        // всегда гарантируем список
        Fragment listFragment = fm.findFragmentByTag(LIST_FRAGMENT_TAG);
        if (listFragment == null) {
            listFragment = new StudentListFragment();
            fm.beginTransaction()
                    .replace(R.id.fragment_container, listFragment, LIST_FRAGMENT_TAG)
                    .commit();
        }

        // если теперь двухпанельный режим – гарантируем правый фрагмент
        if (isTwoPaneLayout()) {
            StudentDetailFragment detailFragment =
                    (StudentDetailFragment) fm.findFragmentByTag(DETAIL_FRAGMENT_TAG);

            if (detailFragment == null) {
                // при повороте из портрета сюда тоже зайдём и создадим фрагмент
                detailFragment = StudentDetailFragment.newInstance(currentStudentId);
                fm.beginTransaction()
                        .replace(R.id.detail_container, detailFragment, DETAIL_FRAGMENT_TAG)
                        .commit();
            } else if (savedInstanceState != null) {
                // обновим на всякий случай выбранного студента
                detailFragment.updateStudent(currentStudentId);
            }
        }
    }

    /**
     * Проверяет наличие контейнера для деталей студента, определяя двухпанельный макет.
     * Возвращает true для планшетов (landscape), false для телефонов (portrait).
     *
     * @return true если макет двухпанельный (есть detail_container), иначе false
     */
    private boolean isTwoPaneLayout() {
        return findViewById(R.id.detail_container) != null;
    }

    /**
     * Обработчик выбора студента из списка. Реализует интерфейс OnStudentSelectedListener.
     * В двухпанельном режиме обновляет фрагмент деталей, в однопанельном заменяет список на детали.
     *
     * @param studentId ID выбранного студента
     */
    @Override
    public void onStudentSelected(int studentId) {
        currentStudentId = studentId;

        if (isTwoPaneLayout()) {
            StudentDetailFragment detailFragment = (StudentDetailFragment)
                    getSupportFragmentManager().findFragmentByTag(DETAIL_FRAGMENT_TAG);
            if (detailFragment == null) {
                detailFragment = StudentDetailFragment.newInstance(studentId);
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.detail_container, detailFragment, DETAIL_FRAGMENT_TAG)
                        .commit();
            } else {
                detailFragment.updateStudent(studentId);
            }
        } else {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragment_container,
                    StudentDetailFragment.newInstance(studentId));
            transaction.addToBackStack(null);
            transaction.commit();
        }
    }

    /**
     * Сохраняет ID текущего студента в состоянии активности перед уничтожением.
     * Вызывается системой перед поворотом экрана или завершением активности.
     *
     * @param outState Bundle для сохранения состояния
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_STUDENT_ID, currentStudentId);
    }
}