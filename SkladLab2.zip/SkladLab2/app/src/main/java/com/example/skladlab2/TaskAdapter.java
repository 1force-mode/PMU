package com.example.skladlab2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.ViewHolder> {

    private List<Task> tasks;

    public TaskAdapter(List<Task> tasks) {
        this.tasks = tasks;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewDescription;
        public TextView textViewCount;
        public Button buttonIncrement;
        public Button buttonDecrement;

        public ViewHolder(View view) {
            super(view);
            textViewDescription = view.findViewById(R.id.textViewTaskDescription);
            textViewCount = view.findViewById(R.id.textViewTaskCount);
            buttonIncrement = view.findViewById(R.id.buttonIncrement);
            buttonDecrement = view.findViewById(R.id.buttonDecrement);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Task task = tasks.get(position);
        holder.textViewDescription.setText(task.getDescription());
        holder.textViewCount.setText(String.valueOf(task.getCount()));

        holder.buttonIncrement.setOnClickListener(v -> {
            task.setCount(task.getCount() + 1);
            notifyItemChanged(holder.getAdapterPosition());
        });

        holder.buttonDecrement.setOnClickListener(v -> {
            int currentPosition = holder.getAdapterPosition();
            if (currentPosition != RecyclerView.NO_POSITION) {
                Task currentTask = tasks.get(currentPosition);
                currentTask.setCount(currentTask.getCount() - 1);
                if (currentTask.getCount() <= 0) {
                    removeTask(currentPosition);
                } else {
                    notifyItemChanged(currentPosition);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    public void addTask(Task task) {
        tasks.add(task);
        notifyItemInserted(tasks.size() - 1);
    }

    public void removeTask(int position) {
        tasks.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, tasks.size());
    }
}