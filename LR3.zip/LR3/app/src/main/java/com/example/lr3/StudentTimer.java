package com.example.lr3;

/**
 * Модель данных для таймера отдельного студента в приложении "Мультитаймер".
 *
 * <p>Представляет состояние одного таймера: идентификатор, имя студента,
 * текущее прошедшее время и статус работы таймера.</p>
 *
 * <p>Неизменяемые поля: {@code id} и {@code name}. Изменяемые:
 * {@code elapsedMillis} и {@code running}.</p>
 *
 * <p>Используется в {@link TimerService} и {@link TimerAdapter}.</p>
 */
public class StudentTimer {

    /** Уникальный идентификатор таймера студента (неизменяемый) */
    private final int id;

    /** Имя студента (неизменяемый) */
    private final String name;

    /** Прошедшее время в миллисекундах */
    private long elapsedMillis;

    /** Статус работы таймера (true = запущен, false = остановлен/на паузе) */
    private boolean running;

    /**
     * Конструктор таймера студента.
     * Инициализирует таймер со временем 0 и остановленным состоянием.
     *
     * @param id   уникальный идентификатор студента
     * @param name имя студента
     */
    public StudentTimer(int id, String name) {
        this.id = id;
        this.name = name;
        this.elapsedMillis = 0;
        this.running = false;
    }

    /**
     * Возвращает уникальный идентификатор таймера.
     *
     * @return ID студента
     */
    public int getId() {
        return id;
    }

    /**
     * Возвращает имя студента.
     *
     * @return имя студента
     */
    public String getName() {
        return name;
    }

    /**
     * Возвращает текущее прошедшее время таймера.
     *
     * @return время в миллисекундах
     */
    public long getElapsedMillis() {
        return elapsedMillis;
    }

    /**
     * Проверяет, запущен ли таймер.
     *
     * @return true, если таймер работает
     */
    public boolean isRunning() {
        return running;
    }

    /**
     * Устанавливает текущее прошедшее время таймера.
     *
     * @param elapsedMillis время в миллисекундах
     */
    public void setElapsedMillis(long elapsedMillis) {
        this.elapsedMillis = elapsedMillis;
    }

    /**
     * Устанавливает статус работы таймера.
     *
     * @param running true для запуска, false для остановки/паузы
     */
    public void setRunning(boolean running) {
        this.running = running;
    }
}