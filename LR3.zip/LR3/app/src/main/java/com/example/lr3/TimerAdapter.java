package com.example.lr3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Адаптер для отображения списка студентов с индивидуальными таймерами в RecyclerView.
 *
 * <p>Обеспечивает добавление, удаление и обновление таймеров студентов,
 * а также обработку действий пользователя на уровне списка.</p>
 */
public class TimerAdapter extends RecyclerView.Adapter<TimerAdapter.TimerViewHolder> {

    /**
     * Интерфейс для обработки нажатий кнопок управления таймерами (Пуск, Пауза, Стоп).
     */
    public interface OnTimerControlListener {
        void onStartClicked(int id);
        void onPauseClicked(int id);
        void onResetClicked(int id);
    }

    /**
     * Интерфейс для обработки удаления студента из списка.
     */
    public interface OnStudentRemoveListener {
        void onRemoveStudent(int id);
    }

    /** Список таймеров студентов, отображаемых в списке */
    private final List<StudentTimer> items = new ArrayList<>();

    /** Слушатель событий управления таймерами */
    private final OnTimerControlListener timerListener;

    /** Слушатель удаления студентов */
    private final OnStudentRemoveListener removeListener;

    /**
     * Конструктор адаптера.
     *
     * @param items исходный список таймеров студентов
     * @param timerListener слушатель управления таймерами
     * @param removeListener слушатель удаления студента
     */
    public TimerAdapter(List<StudentTimer> items, OnTimerControlListener timerListener,
                        OnStudentRemoveListener removeListener) {
        this.items.addAll(items);
        this.timerListener = timerListener;
        this.removeListener = removeListener;
    }

    /**
     * Добавляет нового студента в список и уведомляет RecyclerView.
     *
     * @param student новый студент с таймером
     */
    public void addStudent(StudentTimer student) {
        items.add(student);
        notifyItemInserted(items.size() - 1);
    }

    /**
     * Удаляет студента по ID из списка и обновляет отображение.
     *
     * @param id ID удаляемого студента
     */
    public void removeStudent(int id) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getId() == id) {
                items.remove(i);
                notifyItemRemoved(i);
                notifyItemRangeChanged(i, items.size());
                break;
            }
        }
    }

    /**
     * Обновляет состояние таймера конкретного студента.
     *
     * @param id ID студента
     * @param elapsedMillis текущее прошедшее время в миллисекундах
     * @param isRunning статус работы таймера
     */
    public void updateTimer(int id, long elapsedMillis, boolean isRunning) {
        for (int i = 0; i < items.size(); i++) {
            StudentTimer t = items.get(i);
            if (t.getId() == id) {
                t.setElapsedMillis(elapsedMillis);
                t.setRunning(isRunning);
                notifyItemChanged(i);
                break;
            }
        }
    }

    /**
     * Создает и инициализирует ViewHolder для элемента списка.
     */
    @NonNull
    @Override
    public TimerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_student_timer, parent, false);
        return new TimerViewHolder(v);
    }

    /**
     * Заполняет элементы View данными и устанавливает обработчики кнопок.
     */
    @Override
    public void onBindViewHolder(@NonNull TimerViewHolder holder, int position) {
        StudentTimer timer = items.get(position);
        holder.tvName.setText(timer.getName());
        holder.tvTime.setText(formatTime(timer.getElapsedMillis()));

        holder.btnStart.setOnClickListener(v -> timerListener.onStartClicked(timer.getId()));
        holder.btnPause.setOnClickListener(v -> timerListener.onPauseClicked(timer.getId()));
        holder.btnReset.setOnClickListener(v -> timerListener.onResetClicked(timer.getId()));

        // Кнопка удаления
        holder.btnDelete.setOnClickListener(v -> removeListener.onRemoveStudent(timer.getId()));
    }

    /**
     * Возвращает количество элементов в списке.
     */
    @Override
    public int getItemCount() {
        return items.size();
    }

    /**
     * Форматирует миллисекунды в строку формата "чч:мм:сс".
     *
     * @param millis время в миллисекундах
     * @return отформатированная строка времени
     */
    private String formatTime(long millis) {
        long seconds = millis / 1000;
        long s = seconds % 60;
        long m = (seconds / 60) % 60;
        long h = (seconds / 3600);
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s);
    }

    /**
     * ViewHolder для одного элемента списка студента с таймером.
     * Содержит ссылки на элементы интерфейса иконок и кнопок.
     */
    static class TimerViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvTime;
        Button btnStart, btnPause, btnReset, btnDelete;

        /**
         * Конструктор ViewHolder.
         * Ищет и сохраняет ссылки на элементы разметки.
         *
         * @param itemView корневой view элемента списка
         */
        public TimerViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvTime = itemView.findViewById(R.id.tvTime);
            btnStart = itemView.findViewById(R.id.btnStart);
            btnPause = itemView.findViewById(R.id.btnPause);
            btnReset = itemView.findViewById(R.id.btnReset);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}