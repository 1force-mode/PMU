package com.example.lr3;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.core.app.NotificationCompat;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ForegroundService для управления множественными таймерами студентов.
 *
 * <p>Реализует BoundService с Binder для взаимодействия с {@link MainActivity}.
 * Хранит состояние всех таймеров, обновляет их каждую секунду и отправляет
 * обновления через колбэк {@link TimerUpdateListener}.</p>
 *
 * <p>Ключевые возможности:</p>
 * <ul>
 *     <li>Индивидуальное управление таймерами (пуск/пауза/сброс)</li>
 *     <li>Общее управление всеми таймерами</li>
 *     <li>Автоматическая остановка при отсутствии активных таймеров</li>
 *     <li>Работа в фоне с уведомлением</li>
 * </ul>
 */
public class TimerService extends Service {

    /**
     * Интерфейс для уведомления Activity об обновлениях таймеров.
     */
    public interface TimerUpdateListener {
        /**
         * Вызывается при обновлении состояния таймера.
         *
         * @param studentId    ID студента
         * @param elapsedMillis текущее время в миллисекундах
         * @param isRunning    статус работы таймера
         */
        void onTimerUpdated(int studentId, long elapsedMillis, boolean isRunning);
    }

    /**
     * Binder для BoundService. Предоставляет доступ к TimerService.
     */
    public class LocalBinder extends Binder {
        /**
         * Возвращает экземпляр сервиса.
         *
         * @return текущий TimerService
         */
        public TimerService getService() {
            return TimerService.this;
        }
    }

    /** Binder для клиентов сервиса */
    private final IBinder binder = new LocalBinder();

    /** Хранилище всех таймеров студентов по ID */
    private final Map<Integer, StudentTimer> timers = new HashMap<>();

    /** Метки времени запуска каждого таймера */
    private final Map<Integer, Long> startTimestamps = new HashMap<>();

    /** Колбэк для обновлений таймеров */
    private TimerUpdateListener listener;

    /** Handler для обновлений UI в главном потоке */
    private Handler handler;

    /** Runnable для тика таймеров (каждую секунду) */
    private Runnable tickRunnable;

    /** Флаг наличия активных таймеров */
    private boolean hasRunningTimers = false;

    /** ID уведомления ForegroundService */
    private static final int NOTIFICATION_ID = 1;
    private NotificationCompat.Builder notificationBuilder;

    /**
     * Инициализация ForegroundService.
     * Создает канал уведомлений, запускает foreground режим и настраивает тикание.
     */
    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, getNotification("Мультитаймер запущен"));

        handler = new Handler(Looper.getMainLooper());
        tickRunnable = new Runnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                hasRunningTimers = false;
                for (StudentTimer timer : timers.values()) {
                    if (timer.isRunning()) {
                        hasRunningTimers = true;
                        long start = startTimestamps.getOrDefault(timer.getId(), now);
                        long elapsed = timer.getElapsedMillis() + (now - start);
                        timer.setElapsedMillis(elapsed);
                        startTimestamps.put(timer.getId(), now);
                        if (listener != null) {
                            listener.onTimerUpdated(timer.getId(), elapsed, true);
                        }
                    }
                }
                if (hasRunningTimers) {
                    handler.postDelayed(this, 1000);
                } else {
                    stopSelfIfNeeded();
                }
            }
        };
    }

    /**
     * Возвращает IBinder для привязки клиентов.
     */
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    /**
     * Устанавливает слушатель обновлений таймеров.
     *
     * @param listener колбэк для Activity
     */
    public void setTimerUpdateListener(TimerUpdateListener listener) {
        this.listener = listener;
    }

    /**
     * Инициализирует сервис начальными таймерами (не используется в текущей версии).
     */
    public void initTimers(List<StudentTimer> list) {
        for (StudentTimer t : list) {
            timers.put(t.getId(), t);
            startTimestamps.put(t.getId(), System.currentTimeMillis());
        }
    }

    /**
     * Запускает таймер конкретного студента.
     *
     * @param studentId ID студента
     */
    public void startTimer(int studentId) {
        StudentTimer timer = timers.get(studentId);
        if (timer == null) return;
        if (!timer.isRunning()) {
            timer.setRunning(true);
            startTimestamps.put(studentId, System.currentTimeMillis());
            scheduleTick();
        }
    }

    /**
     * Ставит на паузу таймер студента, сохраняя текущее время.
     *
     * @param studentId ID студента
     */
    public void pauseTimer(int studentId) {
        StudentTimer timer = timers.get(studentId);
        if (timer == null || !timer.isRunning()) return;
        long now = System.currentTimeMillis();
        long start = startTimestamps.getOrDefault(studentId, now);
        timer.setElapsedMillis(timer.getElapsedMillis() + (now - start));
        timer.setRunning(false);
        if (listener != null) {
            listener.onTimerUpdated(studentId, timer.getElapsedMillis(), false);
        }
        stopSelfIfNeeded();
    }

    /**
     * Сбрасывает таймер студента на 0.
     *
     * @param studentId ID студента
     */
    public void resetTimer(int studentId) {
        StudentTimer timer = timers.get(studentId);
        if (timer == null) return;
        timer.setElapsedMillis(0);
        timer.setRunning(false);
        if (listener != null) {
            listener.onTimerUpdated(studentId, 0, false);
        }
        stopSelfIfNeeded();
    }

    /**
     * Запускает ВСЕ таймеры студентов.
     */
    public void startAll() {
        for (StudentTimer t : timers.values()) {
            if (!t.isRunning()) {
                t.setRunning(true);
                startTimestamps.put(t.getId(), System.currentTimeMillis());
            }
        }
        scheduleTick();
    }

    /**
     * Сбрасывает ВСЕ таймеры на 0 (ОБЩ. СТОП).
     */
    public void stopAll() {
        for (StudentTimer t : timers.values()) {
            t.setElapsedMillis(0);
            t.setRunning(false);
            if (listener != null) {
                listener.onTimerUpdated(t.getId(), 0, false);
            }
        }
        hasRunningTimers = false;
        stopSelfIfNeeded();
    }

    /**
     * Добавляет нового студента в сервис.
     *
     * @param student новый студент с таймером
     */
    public void addStudent(StudentTimer student) {
        timers.put(student.getId(), student);
        startTimestamps.put(student.getId(), System.currentTimeMillis());
    }

    /**
     * Удаляет студента из сервиса.
     *
     * @param studentId ID удаляемого студента
     */
    public void removeStudent(int studentId) {
        timers.remove(studentId);
        startTimestamps.remove(studentId);
        stopSelfIfNeeded();
    }

    /**
     * Планирует следующий тик таймеров, если есть активные таймеры.
     */
    private void scheduleTick() {
        if (!hasRunningTimers) {
            hasRunningTimers = true;
            handler.post(tickRunnable);
        }
    }

    /**
     * Автоматически останавливает сервис, если нет активных таймеров и студентов.
     */
    private void stopSelfIfNeeded() {
        boolean anyRunning = false;
        for (StudentTimer t : timers.values()) {
            if (t.isRunning()) {
                anyRunning = true;
                break;
            }
        }
        if (!anyRunning && !timers.isEmpty()) {
            // Оставляем сервис работать, если есть таймеры
        } else if (!anyRunning && timers.isEmpty()) {
            stopSelf();
        }
    }

    /**
     * Создает канал уведомлений для Android 8.0+.
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "timer_service",
                    "Timer Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    /**
     * Создает уведомление ForegroundService.
     *
     * @param content текст уведомления
     * @return готовое Notification
     */
    private Notification getNotification(String content) {
        return new NotificationCompat.Builder(this, "timer_service")
                .setContentTitle("Мультитаймер")
                .setContentText(content)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build();
    }

    /**
     * Освобождение ресурсов при остановке сервиса.
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(tickRunnable);
    }
}