package com.example.lr3;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Главная активность приложения "Мультитаймер".
 * Отображает список студентов с индивидуальными таймерами и предоставляет управление ими.
 *
 * <p>Основные возможности:</p>
 * <ul>
 *     <li>Добавление новых студентов с таймерами</li>
 *     <li>Удаление студентов из списка</li>
 *     <li>Индивидуальное управление таймерами (ПУСК/ПАУЗА/СТОП)</li>
 *     <li>Общее управление всеми таймерами (ОБЩ. ПУСК/ОБЩ. СТОП)</li>
 * </ul>
 *
 * <p>Связывается с {@link TimerService} через Binder для работы таймеров в фоне.</p>
 */
public class MainActivity extends AppCompatActivity implements TimerService.TimerUpdateListener {

    /**
     * RecyclerView для отображения списка студентов с таймерами
     */
    private RecyclerView recyclerView;

    /**
     * Адаптер для управления списком студентов в RecyclerView
     */
    private TimerAdapter adapter;

    /**
     * Кнопки управления
     */
    private Button btnStartAll, btnStopAll, btnExit, btnAddStudent;

    /**
     * Поле ввода имени нового студента
     */
    private EditText etStudentName;

    /**
     * Ссылка на сервис таймеров
     */
    private TimerService timerService;

    /**
     * Флаг привязки к сервису
     */
    private boolean bound = false;

    /**
     * ServiceConnection для привязки к TimerService.
     * Получает IBinder и устанавливает колбэк для обновлений таймеров.
     */
    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            TimerService.LocalBinder binder = (TimerService.LocalBinder) service;
            timerService = binder.getService();
            timerService.setTimerUpdateListener(MainActivity.this);
            bound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            bound = false;
            timerService = null;
        }
    };

    /**
     * Инициализация основной активности.
     * Настраивает UI, RecyclerView, сервис и обработчики кнопок.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupRecyclerView();
        setupService();
        setupButtons();
    }

    /**
     * Инициализация всех элементов интерфейса из layout.
     */
    private void initViews() {
        recyclerView = findViewById(R.id.recyclerView);
        btnStartAll = findViewById(R.id.btnStartAll);
        btnStopAll = findViewById(R.id.btnStopAll);
        btnExit = findViewById(R.id.btnExit);
        btnAddStudent = findViewById(R.id.btnAddStudent);
        etStudentName = findViewById(R.id.etStudentName);
    }

    /**
     * Настройка RecyclerView с пустым списком студентов.
     * Студенты добавляются динамически кнопкой "Добавить".
     *
     * <p>Устанавливает колбэки для управления таймерами и удаления студентов.</p>
     */
    private void setupRecyclerView() {
        List<StudentTimer> students = new ArrayList<>();

        adapter = new TimerAdapter(students, new TimerAdapter.OnTimerControlListener() {
            @Override
            public void onStartClicked(int id) {
                if (bound) timerService.startTimer(id);
            }

            @Override
            public void onPauseClicked(int id) {
                if (bound) timerService.pauseTimer(id);
            }

            @Override
            public void onResetClicked(int id) {
                if (bound) timerService.resetTimer(id);
            }
        }, new TimerAdapter.OnStudentRemoveListener() {
            @Override
            public void onRemoveStudent(int id) {
                if (bound) timerService.removeStudent(id);
                adapter.removeStudent(id);
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    /**
     * Запуск и привязка к ForegroundService TimerService.
     * Использует startForegroundService для работы в фоне.
     */
    private void setupService() {
        Intent serviceIntent = new Intent(this, TimerService.class);
        startForegroundService(serviceIntent); // ForegroundService
        bindService(serviceIntent, connection, Context.BIND_AUTO_CREATE);
    }

    /**
     * Настройка обработчиков кнопок управления.
     *
     * <ul>
     *     <li>ОБЩ. ПУСК — запуск всех таймеров</li>
     *     <li>ОБЩ. СТОП — сброс всех таймеров на 0</li>
     *     <li>Добавить — создание нового студента</li>
     *     <li>Выход — закрытие приложения</li>
     * </ul>
     */
    private void setupButtons() {
        btnStartAll.setOnClickListener(v -> {
            if (bound) timerService.startAll();
        });

        btnStopAll.setOnClickListener(v -> {
            if (bound) timerService.stopAll();
        });

        btnAddStudent.setOnClickListener(v -> {
            String name = etStudentName.getText().toString().trim();
            if (!name.isEmpty()) {
                int newId = generateId();
                StudentTimer newStudent = new StudentTimer(newId, name);
                adapter.addStudent(newStudent);
                if (bound) timerService.addStudent(newStudent);
                etStudentName.setText("");
            }
        });

        btnExit.setOnClickListener(v -> finish());
    }

    /**
     * Генерация уникального ID для нового студента.
     * Использует текущую временную метку для уникальности.
     *
     * @return уникальный целочисленный идентификатор
     */
    private int generateId() {
        return (int) System.currentTimeMillis();
    }

    /**
     * Освобождение ресурсов при уничтожении активности.
     * Отписывается от обновлений сервиса и отвязывается от него.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bound) {
            timerService.setTimerUpdateListener(null);
            unbindService(connection);
            bound = false;
        }
    }

    /**
     * Колбэк обновления таймера от сервиса.
     * Обновляет состояние таймера в адаптере RecyclerView.
     *
     * @param studentId    ID студента
     * @param elapsedMillis текущее прошедшее время в миллисекундах
     * @param isRunning    флаг работы таймера
     */
    @Override
    public void onTimerUpdated(int studentId, long elapsedMillis, boolean isRunning) {
        adapter.updateTimer(studentId, elapsedMillis, isRunning);
    }
}